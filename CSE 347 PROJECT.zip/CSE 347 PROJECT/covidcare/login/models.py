########  login models

from django.db import models
from signup.models import TableUser, TableDoctorUser

# Create your models here.


class TablePersonalProfile(models.Model):
    user = models.ForeignKey(TableUser, on_delete=models.CASCADE)
    systolic_pressure = models.IntegerField(null=True)
    diastolic_pressure = models.IntegerField(null=True)
    blood_sugar_level = models.IntegerField(null=True)
    oxygen_saturation = models.IntegerField(null=True)
    date_recorded = models.DateTimeField(auto_now_add=True)



class TablePosts(models.Model):
    # is a weak table, so has another id
    user = models.ForeignKey(TableUser, on_delete=models.CASCADE)

    post_date = models.DateTimeField(auto_now_add=True)
    post_description = models.CharField(max_length = 200)
    bkash_no = models.IntegerField()
    payment_value = models.FloatField()


class TableConsult(models.Model):
    user = models.ForeignKey(TableUser, on_delete=models.CASCADE)
    doctor = models.ForeignKey(TableDoctorUser, on_delete=models.CASCADE)
    post = models.ForeignKey(TablePosts, on_delete=models.CASCADE)

    prescription = models.CharField(max_length = 200, null=True)
    diet_chart = models.CharField(max_length = 200, null=True)
    consultation_done = models.BooleanField()


class TableVideos(models.Model):
    user = models.ForeignKey(TableUser, on_delete=models.CASCADE)
    doctor = models.ForeignKey(TableDoctorUser, on_delete=models.CASCADE)
    caption = models.CharField(max_length = 50)
    post_date = models.DateTimeField(auto_now_add=True)
    description = models.CharField(max_length = 200)
    video = models.FileField(upload_to="images/%y")


class TableOxygenCylinders(models.Model):
    volume = models.FloatField()
    price = models.FloatField()
    discount = models.FloatField()
    discount_price = models.FloatField()
    units_available = models.IntegerField()
    cylinder_description = models.CharField(max_length=100)
    cylinder_pic = models.ImageField(null=True, default="cylinder.png")

class TableBuy(models.Model):
    user=models.ForeignKey(TableUser, on_delete=models.CASCADE)
    cylinder = models.ForeignKey(TableOxygenCylinders, on_delete=models.CASCADE)
    purchase_date = models.DateTimeField(auto_now_add=True)
    quantity = models.IntegerField()
    revenue_collected = models.FloatField()


