##### login
from django.shortcuts import render, HttpResponse, redirect
from signup.models import TableUser, TableNormalUser, TableSpecialUser, TableDoctorUser, TableManagerUser
from .models import TablePosts, TablePersonalProfile, TableConsult, TableVideos, TableOxygenCylinders, TableBuy
from django.urls import reverse
from django.contrib import messages
from datetime import datetime
from django.contrib.auth.hashers import make_password, check_password



# so that we can insert values in user table

# Create your views here.


def checkRevenue(request):
    try:
        user_id = request.session['user_id']
        if request.session['user_type'] == "manager":
            allDoctors = TableDoctorUser.objects.all()
            allPurchase = TableBuy.objects.all()
            total_revenue_doctors = 0
            total_revenue_cylinders = 0
            for doctor in allDoctors:
                total_revenue_doctors += doctor.revenue_collected
            for purchase in allPurchase:
                total_revenue_cylinders += purchase.revenue_collected
            request.session['total_revenue_doctors'] = total_revenue_doctors
            request.session['total_revenue_cylinders'] = total_revenue_cylinders


            return render(request, 'login/checkRevenue.html')
        else:
            return HttpResponse("sorry. only managers are allowed to access this feature")
    except KeyError:
        pass
    return render(request, 'login/login.html')



def showOxygenCylinderOrderList(request):
    try:
        user_id = request.session['user_id']
        if request.session['user_type'] == "manager":
            allPurchaseInfo = TableBuy.objects.all()
            context = {'allPurchaseInfo':allPurchaseInfo}
            return render(request, 'login/showOxygenCylinderOrderList.html', context)
        else:
            return HttpResponse("sorry. only managers are allowed to access this feature")
    except KeyError:
        pass
    return render(request, 'login/login.html')


def buyOxygenCylinders(request):
    try:
        user_id = request.session['user_id']

        if request.session['user_type'] == "normal" or request.session['user_type'] == "special":
            if request.method == "POST":
                chosen_cylinder_id = request.POST['chosen_cylinder']
                quantity = int(request.POST['quantity'])


                cylinder = TableOxygenCylinders.objects.get(id=chosen_cylinder_id)
                if request.session['user_type'] == "special":
                    revenue_collected = (cylinder.discount_price * quantity)
                else:
                    revenue_collected = (cylinder.price * quantity)
                if cylinder.units_available >= quantity:
                    ins = TableBuy(user_id=user_id, cylinder_id=chosen_cylinder_id, quantity=quantity,
                                   revenue_collected=revenue_collected)
                    ins.save()  # to write the values in the database
                    cylinder.units_available = cylinder.units_available - quantity
                    cylinder.save()
                    messages.add_message(request, messages.INFO, 'Purchase Successful')
                else:
                    messages.add_message(request, messages.INFO, 'Sorry, we are short of this Oxygen Cylinder at the moment.')
                # return render(request, 'login/buyOxygenCylinders.html')
                # return redirect(reverse('userhome'))
            user = TableUser.objects.get(id=user_id)
            allCylinders = TableOxygenCylinders.objects.all()
            context = {'user':user, 'allCylinders':allCylinders}
            return render(request, 'login/buyOxygenCylinders.html',context)
        else:
            return HttpResponse("Sorry, only users are allowed to access this feature")
    except KeyError:
        pass
    return render(request, 'login/userLogin.html')



def addOxygenCylinders(request):
    try:
        user_id = request.session['user_id']
        user = TableUser.objects.get(id=user_id)
        if request.session['user_type'] == "manager":
            if request.method == "POST":
                cylinder_pic = request.FILES.get('cylinder_pic')
                volume = request.POST['volume']
                price = request.POST['price']
                discount = request.POST['discount']
                units_available = request.POST['units_available']
                description = request.POST['description']

                discount_price = int(price) - int (discount)



                ins = TableOxygenCylinders(volume=volume, cylinder_pic=cylinder_pic, price=price,
                                  discount=discount, discount_price=discount_price,
                                  units_available=units_available, cylinder_description=description)
                ins.save()  # to write the values in the database
                messages.add_message(request, messages.INFO, 'Oxygen Cylinder has been added successfully')

                return redirect(reverse('managerhome'))
            return render(request, 'login/addOxygenCylinders.html')
        else:
            return HttpResponse("Sorry, only managers are allowed to access this feature")
    except KeyError:
        pass
    return render(request, 'login/login.html')




def updateOxygenCylinderInventory(request):
    user_id = request.session['user_id']
    user = TableUser.objects.get(id=user_id)
    if request.method == "POST":
        chosen_cylinder_id = request.POST['chosen_cylinder']
        price = request.POST['price']
        description = request.POST['description']
        units_added = request.POST['units']
        discount = request.POST['discount']

        cylinder = TableOxygenCylinders.objects.get(id=chosen_cylinder_id)
        print("chosen cylinder is: ")
        print(cylinder.id)
        print(cylinder.price)
        if price:
            cylinder.price = price
            cylinder.save()
        if description:
            cylinder.cylinder_description = description
            cylinder.save()
        if units_added:
            cylinder.units_available = cylinder.units_available + int(units_added)
            cylinder.save()
        if discount:
            cylinder.discount = int(discount)
            cylinder.save()

        messages.add_message(request, messages.INFO, 'Inventory has been updated successfully')

    cylinders = TableOxygenCylinders.objects.all()

    context = {'cylinders': cylinders}
    return render(request, 'login/updateOxygenCylinderInventory.html', context)


def postVideos(request):
    try:
        user_id = request.session['user_id']
        if request.session['user_type'] == "doctor":
            if request.method == "POST":
                video_tutorial = request.FILES.get('video_tutorial')
                caption = request.POST['caption']
                description = request.POST['description']

                user = TableUser.objects.get(id=user_id)
                doctor_id = TableDoctorUser.objects.get(doctor_user_id=user_id).id

                ins = TableVideos(user_id=user_id, doctor_id=doctor_id, caption=caption,
                                  description=description, video=video_tutorial)
                ins.save()  # to write the values in the database
                messages.add_message(request,messages.INFO,'Video Uploaded Successfully')
                return render(request, 'login/postVideoTutorials.html')
                # return redirect(reverse('doctorhome'))
            return render(request, 'login/postVideoTutorials.html')
        else:
            return HttpResponse("Sorry, only doctors are allowed to post videos")
    except KeyError:
        pass
    return render(request, 'login/login.html')


def watchVideos(request):
    try:
        user_id = request.session['user_id']
        allVideos = TableVideos.objects.all()
        allUsers = TableUser.objects.all()

        context = {'allVideos': allVideos, 'allUsers': allUsers}
        return render(request, 'login/watchVideos.html', context)

    except KeyError:
        pass
    return render(request, 'login/login.html')


def checkBalance(request):
    user_id = request.session['user_id']
    print(user_id)
    user = TableUser.objects.get(id=user_id)
    doctor = TableDoctorUser.objects.get(doctor_user_id=user_id)
    context = {'doctor': doctor, 'user': user}
    return render(request, 'login/checkBalance.html', context)




def myLogout(request):
    try:
        del request.session['user_id']
        request.session.flush()
    except KeyError:
        pass
    return redirect(reverse('home'))



def userhome(request):
    return render(request, 'login/userhome.html')


def doctorhome(request):
    return render(request, 'login/doctorhome.html')


def managerhome(request):
    return render(request, 'login/managerhome.html')




def uploadProfilePic(request):
    if request.method == "POST":
        profile_pic = request.FILES.get('profile_pic')

        user_id = request.session['user_id']

        user = TableUser.objects.get(id=user_id)
        user.profile_pic = profile_pic
        user.save()
        request.session['profile_pic'] = user.profile_pic.url
        messages.add_message(request, messages.INFO, "Profile Picture Uploaded Successfully")


    return render(request, 'login/uploadProfilePic.html')


def login(request):
    try:
        user_type = request.session['user_type']
        if user_type == "normal" or user_type =="special":
            return render(request, 'login/userhome.html')
        elif user_type == "doctor":
            return render(request, 'login/doctorhome.html')
        elif user_type =="manager":
            return render(request,'login/managerhome.html')
    except KeyError:
        if request.method == "POST":
            username = request.POST['username']
            password = request.POST['password']

            user = TableUser.objects.all()
            flag = 0
            for u in user:
                if u.username == username and check_password(password, u.password):
                    flag = 1;
                    # to get user id:
                    user = u
                    request.session['username'] = user.username
                    request.session['email'] = user.email
                    request.session['user_id'] = user.id
                    request.session['user_type'] = user.user_type
                    request.session['profile_pic'] = user.profile_pic.url
                    # request.session.set_expiry(None)

                    context = {'user': user}
                    if u.user_type == "normal" or u.user_type == "special":
                        messages.add_message(request, messages.SUCCESS, 'Login Successful')
                        return redirect(reverse('userhome'))
                    elif u.user_type == "doctor":
                        doctor_user_id = user.id
                        doctor = TableDoctorUser.objects.get(doctor_user_id=doctor_user_id)
                        request.session['specialization'] = doctor.specialization
                        request.session['highest_medical_degree'] = doctor.highest_medical_degree
                        messages.add_message(request, messages.SUCCESS, 'Login Successful')
                        return redirect(reverse('doctorhome'))
                    elif u.user_type == "manager":
                        manager_user_id = user.id
                        manager = TableManagerUser.objects.get(manager_user_id=manager_user_id)
                        request.session['employed'] = manager.employed
                        if (manager.employed == 0):
                            try:
                                messages.add_message(request, messages.INFO,
                                                     'You have not been employed yet. Please Login in later')
                                del request.session['user_id']
                                request.session.flush()
                            except KeyError:
                                pass
                            return redirect(reverse('userLogin'))
                        else:
                            messages.add_message(request, messages.INFO, 'Login Successful')
                            return redirect(reverse('managerhome'))
            if flag == 0:
                messages.add_message(request, messages.INFO, 'Invalid username or password')

        return render(request, 'login/userLogin.html')
    # return render(request, 'login/login.html')


def userLogin(request):
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']

        user = TableUser.objects.all()
        flag = 0
        for u in user:
            if u.username == username and check_password(password, u.password):
                flag = 1;
                # to get user id:
                user = u
                request.session['username'] = user.username
                request.session['email'] = user.email
                request.session['user_id'] = user.id
                request.session['user_type'] = user.user_type
                request.session['profile_pic'] = user.profile_pic.url
                # request.session.set_expiry(None)

                context = {'user': user}
                if u.user_type == "normal" or u.user_type == "special":
                    messages.add_message(request, messages.SUCCESS, 'Login Successful')
                    return redirect(reverse('userhome'))
                elif u.user_type == "doctor":
                    doctor_user_id = user.id
                    doctor = TableDoctorUser.objects.get(doctor_user_id=doctor_user_id)
                    request.session['specialization'] = doctor.specialization
                    request.session['highest_medical_degree'] = doctor.highest_medical_degree
                    messages.add_message(request, messages.SUCCESS, 'Login Successful')
                    return redirect(reverse('doctorhome'))
                elif u.user_type == "manager":
                    manager_user_id = user.id
                    manager = TableManagerUser.objects.get(manager_user_id=manager_user_id)
                    request.session['employed'] = manager.employed
                    if (manager.employed == 0):
                        try:
                            messages.add_message(request, messages.INFO,'You have not been employed yet. Please Login in later')
                            del request.session['user_id']
                            request.session.flush()
                        except KeyError:
                            pass
                        return redirect(reverse('userLogin'))
                    else:
                        messages.add_message(request, messages.INFO, 'Login Successful')
                        return redirect(reverse('managerhome'))
        if flag == 0:
            messages.add_message(request,messages.INFO,'Invalid username or password')

    return render(request, 'login/userLogin.html')


def prescription(request):
    user_id = request.session['user_id']

    ConsultRows = TableConsult.objects.filter(user_id=user_id).order_by('-id')
    PostsRows = TablePosts.objects.filter(user_id=user_id).order_by('-id')
    user = TableUser.objects.get(id=user_id)

    context = {'ConsultRows': ConsultRows, 'PostRows': PostsRows, 'user': user}

    return render(request, 'login/prescription.html', context)


def inputMedicalInformation(request):
    user_id = request.session['user_id']

    user = TableUser.objects.get(id=user_id)

    if request.method == "POST":
        systolic_pressure = request.POST['systolic_pressure']
        diastolic_pressure = request.POST['diastolic_pressure']
        blood_sugar_level = request.POST['blood_sugar_level']
        oxygen_saturation = request.POST['oxygen_saturation']

        ins = TablePersonalProfile(systolic_pressure=systolic_pressure, diastolic_pressure=diastolic_pressure,
                                   blood_sugar_level=blood_sugar_level, oxygen_saturation=oxygen_saturation,
                                   user_id=user_id)
        ins.save()
        messages.add_message(request, messages.INFO, "Medical Information has been saved Successfully")
    context = {'user': user}
    return render(request, 'login/inputMedicalInfo.html', context)


def seeMedicalInformation(request):
    user_id = request.session['user_id']

    user = TableUser.objects.get(id=user_id)
    PersonalProfileRows = TablePersonalProfile.objects.filter(user_id=user_id)

    context = {'user': user, 'PersonalProfileRows': PersonalProfileRows}
    return render(request, 'login/seeMedicalInfo.html', context)


def giveConsultation(request):
    user_id = request.session['user_id']
    doctor = TableDoctorUser.objects.get(doctor_user_id=user_id)
    doctor_id = doctor.id

    if request.method == "POST":
        print("this is give consultation post")
        prescription = request.POST['given_consultation']
        diet_chart = request.POST['assigned_diet_chart']
        post_id = request.POST['chosen_post']
        print("this is the post id chosen")
        print(post_id)
        consult = TableConsult.objects.get(post_id=post_id)
        consult.prescription = prescription
        consult.diet_chart = diet_chart
        consult.consultation_done = 1
        consult.save()
        # TableConsult.objects.filter(post_id=post_id).update(prescription= prescription, diet_chart=diet_chart)

        # ins = TableConsult (prescription = prescription, diet_chart=diet_chart)
        # ins.save()

    # doctors = TableDoctorUser.objects.all()
    consultRows = TableConsult.objects.filter(doctor_id=doctor_id)

    postLists = []
    for consultRow in consultRows:
        if consultRow.doctor_id == doctor_id and consultRow.consultation_done == 0:
            postLists.append(consultRow.post_id)

    posts = TablePosts.objects.filter(pk__in=postLists)

    for post in posts:
        print(post.id)
    context = {'posts': posts}

    return render(request, 'login/giveConsultation.html', context)


def consult(request):
    user_id = request.session['user_id']
    user = TableUser.objects.get(id=user_id)
    if request.method == "POST":
        post_description = request.POST['post_description']
        chosen_doctor_id = request.POST['chosen_doctor']
        bkash_no = request.POST['payment']

        user_type = user.user_type
        # user_type = TableUser.objects.get(id=user_id).user_type

        # logic to decide payment value
        # payment_value = 300

        doctor = TableDoctorUser.objects.get(id=chosen_doctor_id)
        revenue_collected =(0.2 * doctor.doctor_fee)
        doctor.revenue_collected += revenue_collected
        doctor.save()
        doctor.balance += doctor.doctor_fee-revenue_collected
        doctor.save()
        ins = TablePosts(user_id=user_id, post_description=post_description, bkash_no=bkash_no,
                         payment_value=doctor.doctor_fee)
        ins.save()
        last_row = TablePosts.objects.all().last()
        post_id = last_row.id
        ins = TableConsult(doctor_id=chosen_doctor_id, post_id=post_id, consultation_done=0, user_id=user_id)
        ins.save()
        messages.add_message(request, messages.SUCCESS, 'Your problem has been successfully posted')

    doctors = TableDoctorUser.objects.all()
    doctorusers = TableUser.objects.filter(user_type='doctor')

    context = {'doctors': doctors, 'doctorusers': doctorusers, 'user': user}
    return render(request, 'login/consult.html', context)
