#login
from django.contrib import admin
from django.urls import path, include
from .import views

urlpatterns = [
    path('', views.login, name='login'),
    path('userhome/', views.userhome, name='userhome'),
    path('doctorhome/',views.doctorhome,name='doctorhome'),
    path('managerhome/', views.managerhome, name='managerhome'),

    path('userLogin/', views.userLogin, name='userLogin'),
    path('consult/',views.consult, name='consult'),
    path('giveconsultation/', views.giveConsultation, name='giveConsultation'),
    path('prescription/', views.prescription, name='prescription'),
    path('inputmedicalinformation/', views.inputMedicalInformation, name='inputMedicalInfo'),
    path('seemedicalinformation/', views.seeMedicalInformation, name='seeMedicalInfo'),
    path('buyOxygenCylinders/', views.buyOxygenCylinders, name='buyOxygenCylinders'),
    path('watchvideos/', views.watchVideos, name='watchVideos'),
    path('buyOxygenCylinders/',views.buyOxygenCylinders, name='buyOxygenCylinders'),
    path('logout/', views.myLogout, name='logout'),

    path('checkbalance/', views.checkBalance, name='checkBalance'),
    path('postvideos/', views.postVideos, name='postVideos'),


    path('uploadprofilepic/', views.uploadProfilePic, name = 'uploadProfilePic'),

    path('addOxygenCylinders/', views.addOxygenCylinders, name='addOxygenCylinders'),
    path('updateOxygenCylinderInventory/', views.updateOxygenCylinderInventory, name='updateOxygenCylinderInventory'),
    path('showOxygenCylinderOrderList/', views.showOxygenCylinderOrderList, name='showOxygenCylinderOrderList'),
    path('checkRevenue/', views.checkRevenue, name='checkRevenue'),

]
