#signup
from django.contrib import admin
from django.urls import path
from .import views

urlpatterns = [
    path('', views.signup, name='signup'),
    path('normalUserSignup/', views.normalUserSignup, name='normalUserSignup'),
    path('specialUserSignup/', views.specialUserSignup, name='specialUserSignup'),
    path('doctorSignup/', views.doctorSignup, name='doctorSignup'),
    path('managerSignup/', views.managerSignup, name='managerSignup'),

]

