##### signup
from django.contrib import admin
from .models import TableUser, TableNormalUser, TableSpecialUser, TableDoctorUser, TableManagerUser


# Register your models here.

admin.site.register(TableUser)
admin.site.register(TableNormalUser)
admin.site.register(TableSpecialUser)
admin.site.register(TableDoctorUser)
admin.site.register(TableManagerUser)
