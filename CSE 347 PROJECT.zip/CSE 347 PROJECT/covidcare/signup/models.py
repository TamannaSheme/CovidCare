###### signup
from django.db import models

# Create your models here.
class TableUser(models.Model):
    # user_id = models.IntegerField()
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    gender = models.CharField(max_length=6)
    email = models.EmailField()
    phone = models.CharField(max_length=11)
    username = models.CharField(max_length=20)
    password = models.CharField(max_length=300)
    # password = models.BinaryField()
    user_type = models.CharField(max_length=10)

    profile_pic = models.ImageField(null=True, default="profile1.png")

    # add picuture later
    # date = models.DateTimeField(auto_now_add=True)

    def __str__(self):  # shows in admin
        return 'Name: ' + self.first_name + self.last_name

    # class Meta:
    #    unique_together = ("username", "password")


class TableNormalUser(models.Model):
    # normal_user_id = models.ForeignKey(TableUser, on_delete=models.CASCADE, primary_key=True)
    normal_user = models.ForeignKey(TableUser, on_delete=models.CASCADE)
    occupation = models.CharField(max_length=30)
    blood_group = models.CharField(max_length=5)

    def __str__(self):  # shows in admin
        return 'User id: ' + self.normal_user_id

class TableSpecialUser(models.Model):
    special_user = models.ForeignKey(TableUser, on_delete=models.CASCADE)
    company = models.CharField(max_length=30)
    blood_group = models.CharField(max_length=5)

    def __str__(self):  # shows in admin
        return 'User id: ' + self.special_user_id

class TableDoctorUser(models.Model):
    doctor_user = models.ForeignKey(TableUser, on_delete=models.CASCADE)
    specialization = models.CharField(max_length=30)
    highest_medical_degree = models.CharField(max_length=30)
    # working_hours = models.CharField(max_length=10)
    doctor_fee = models.FloatField()
    revenue_collected = models.FloatField()
    balance = models.FloatField()   #error: check if you can update values in balance

    def __str__(self):  # shows in admin
        return 'User id: ' + self.doctor_user_id

class TableManagerUser(models.Model):
    manager_user = models.ForeignKey(TableUser, on_delete=models.CASCADE)
    address = models.CharField(max_length=200)
    salary = models.FloatField(null=True, blank=True)
    cv = models.FileField(upload_to = "employee_cv/%y")
    employed = models.BooleanField()

    def __str__(self):  # shows in admin
        return 'User id: ' + str(self.manager_user_id)