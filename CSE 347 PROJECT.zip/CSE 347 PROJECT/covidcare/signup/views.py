##### signup
from django.shortcuts import render, HttpResponse, redirect
from .models import TableUser, TableNormalUser, TableSpecialUser, TableDoctorUser, TableManagerUser  # so that we can insert values in user table
from django.contrib import messages
from django.urls import reverse
from django.contrib.auth.hashers import make_password, check_password
# import bcrypt
# Create your views here.


def checkValidUsernameAndPass(username, password):
    user = TableUser.objects.all()

    # u.password == password
    for u in user:

        # if u.username == username and bcrypt.checkpw(password.encode("utf-8"), u.password):
        #     return 0

        if u.username == username and check_password(password, u.password):
            return 0


    if (any(x.isupper() for x in password) and any(x.islower() for x in password)
            and any(x.isdigit() for x in password) and len(password) >= 8):
        return 1
    else:
        return 0


def signup(request):
    # return HttpResponse("this is signup page")
    return render(request, 'signup/signup.html')





def normalUserSignup(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        gender = request.POST['gender']
        email = request.POST['email']
        phone = request.POST['phone']
        occupation = request.POST['occupation']
        blood_group = request.POST['blood_group']
        username = request.POST['username']
        password = request.POST['password']
        hashed_password = make_password(password)

        # check if the username and password is unique/valid


        check_value = checkValidUsernameAndPass(username, password)

        if check_value == 1:
            ins = TableUser(first_name=first_name, last_name=last_name, gender=gender, email=email, phone=phone,
                            username=username, password=hashed_password, user_type='normal')
            ins.save()  # to write the values in the database


            last_row = TableUser.objects.all().last()
            normal_user_id = last_row.id
            ins2 = TableNormalUser(normal_user_id=normal_user_id, occupation=occupation, blood_group=blood_group)
            ins2.save()
        elif check_value == 0:
            messages.add_message(request, messages.ERROR, 'Unable to Sign up. Please use a different username or password')
            return render(request, 'signup/normalUserSignup.html')
        messages.add_message(request, messages.SUCCESS, 'Sign Up Successful. Log in Now')
        return redirect(reverse('userLogin'))
    return render(request, 'signup/normalUserSignup.html')


def specialUserSignup(request):
    if request.method == "POST":
        print("this is post")
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        gender = request.POST['gender']
        email = request.POST['email']
        phone = request.POST['phone']
        company = request.POST['company']
        blood_group = request.POST['blood_group']
        username = request.POST['username']
        password = request.POST['password']
        hashed_password = make_password(password)

        check_value = checkValidUsernameAndPass(username, password)
        if check_value == 1:

            # now, insert these values in TableUser
            ins = TableUser(first_name=first_name, last_name=last_name, gender=gender, email=email, phone=phone,
                            username=username, password=hashed_password, user_type='special')
            ins.save()  # to write the values in the database

            last_row = TableUser.objects.all().last()
            special_user_id = last_row.id
            # print("here is your id: ", normal_user_id)
            ins2 = TableSpecialUser(special_user_id=special_user_id, company=company, blood_group=blood_group)
            ins2.save()
        elif check_value == 0:
            messages.add_message(request, messages.ERROR, 'Unable to Sign up.Please use a different username or password')
            return render(request, 'signup/specialUserSignup.html')
            # return render(request, 'signup/signupFail.html')
        messages.add_message(request, messages.SUCCESS, 'Sign Up Successful. Log in now')
        return redirect(reverse('userLogin'))
        # return render(request, 'signup/signupSuccess.html')
    return render(request,'signup/specialUserSignup.html')


def doctorSignup(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        gender = request.POST['gender']
        email = request.POST['email']
        phone = request.POST['phone']

        specialization = request.POST['specialization']
        highest_medical_degree = request.POST['highest_medical_degree']
        # working_hours = request.POST['working_hours']
        doctor_fee = request.POST['fee']

        username = request.POST['username']
        password = request.POST['password']
        hashed_password = make_password(password)

        check_value = checkValidUsernameAndPass(username, password)
        if check_value == 1:

            # now, insert these values in TableUser
            ins = TableUser(first_name=first_name, last_name=last_name, gender=gender, email=email, phone=phone,
                        username=username, password=hashed_password, user_type='doctor')
            ins.save()  # to write the values in the database

            last_row = TableUser.objects.all().last()
            doctor_user_id = last_row.id
            ins2 = TableDoctorUser(doctor_user_id=doctor_user_id, specialization=specialization,
                               highest_medical_degree=highest_medical_degree,
                               doctor_fee=doctor_fee, balance=0, revenue_collected =0)
            ins2.save()
        elif check_value == 0:
            messages.add_message(request, messages.ERROR, 'Unable to Sign up. Please use a different username or password')
            # return render(request, 'signup/doctorSignup.html')
            return render(request, 'signup/doctorSignup.html')

        messages.add_message(request, messages.SUCCESS, 'Sign Up Successful. Log in to your Account.')
        # return redirect(reverse('login'))
        return redirect(reverse('userLogin'))
        # return render(request, 'signup/signupSuccess.html')

    return render(request, 'signup/doctorSignup.html')



def managerSignup(request):
    if request.method == "POST":
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        gender = request.POST['gender']
        email = request.POST['email']
        phone = request.POST['phone']

        address = request.POST['address']
        cv = request.FILES.get('cv')


        username = request.POST['username']
        password = request.POST['password']
        hashed_password = make_password(password)

        check_value = checkValidUsernameAndPass(username, password)
        if check_value == 1:

            # now, insert these values in TableUser
            ins = TableUser(first_name=first_name, last_name=last_name, gender=gender, email=email, phone=phone,
                        username=username, password=hashed_password, user_type='manager')
            ins.save()  # to write the values in the database

            last_row = TableUser.objects.all().last()
            manager_user_id = last_row.id
            ins2 = TableManagerUser(manager_user_id=manager_user_id, address=address, employed=0, cv=cv)
            ins2.save()
        elif check_value == 0:
            messages.add_message(request, messages.ERROR, 'Unable to Sign up. Please use a different username or password')
            # return render(request, 'signup/doctorSignup.html')
            # return render(request, 'signup/signupFail.html')
            return render(request, 'signup/managerSignup.html')

        messages.add_message(request, messages.SUCCESS, 'Sign Up Successful.Log in now')
        # return redirect(reverse('login'))
        # return render(request, 'signup/signupSuccess.html')
        return redirect(reverse('userLogin'))

    return render(request, 'signup/managerSignup.html')

