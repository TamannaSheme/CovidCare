###### home
from django.shortcuts import render, HttpResponse


# Create your views here.

def home(request):
    # return HttpResponse("this is my home page")
    return render(request, 'home.html')


def faq(request):
    # return HttpResponse("this is faq page")
    context = {'Name': 'Maha', 'Age': '22'}
    return render(request, 'faq.html', context)


# def signup(request):
#     # return HttpResponse("this is signup page")
#     return render(request, 'signup.html')
#
# def login(request):
#     # return HttpResponse("this is login page")
#     return render(request, 'login.html')



def prevent(request):
    # return HttpResponse("this is signup page")

    return render(request, 'prevent.html')


def covid(request):
    # return HttpResponse("this is signup page")
    return render(request, 'covid.html')


def contactus(request):
    # return HttpResponse("this is signup page")

    return render(request, 'contactus.html')


def covidBangladesh(request):
    # return HttpResponse("this is signup page")

    return render(request, 'covidBangladesh.html')
