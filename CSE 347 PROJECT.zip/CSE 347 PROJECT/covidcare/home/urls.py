from django.contrib import admin
from django.urls import path
from .import views


urlpatterns = [
    path('', views.home, name='home'),  #from covidcare\urls.py  it came here
    path('faq', views.faq, name='faq'),
   # path('signup', views.signup, name='signup'),
   #  path('login', views.login, name='login'),
    path('covid', views.covid, name='covid'),
    path('prevent', views.prevent, name='prevent'),
    path('contactus', views.contactus, name='contactus'),
    path('covidBangladesh', views.covidBangladesh, name='covidBangladesh'),

    #path('normalUserSignup', views.normalUserSignup, name='normalUserSignup'),
    # path('specialUserSignup', views.specialUserSignup, name='specialUserSignup'),
    # path('doctorSignup', views.doctorSignup, name='doctorSignup'),

]
