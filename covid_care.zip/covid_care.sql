-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 07, 2021 at 04:24 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `covid_care`
--

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session'),
(25, 'Can add table doctor user', 7, 'add_tabledoctoruser'),
(26, 'Can change table doctor user', 7, 'change_tabledoctoruser'),
(27, 'Can delete table doctor user', 7, 'delete_tabledoctoruser'),
(28, 'Can view table doctor user', 7, 'view_tabledoctoruser'),
(29, 'Can add table manager user', 8, 'add_tablemanageruser'),
(30, 'Can change table manager user', 8, 'change_tablemanageruser'),
(31, 'Can delete table manager user', 8, 'delete_tablemanageruser'),
(32, 'Can view table manager user', 8, 'view_tablemanageruser'),
(33, 'Can add table user', 9, 'add_tableuser'),
(34, 'Can change table user', 9, 'change_tableuser'),
(35, 'Can delete table user', 9, 'delete_tableuser'),
(36, 'Can view table user', 9, 'view_tableuser'),
(37, 'Can add table normal user', 10, 'add_tablenormaluser'),
(38, 'Can change table normal user', 10, 'change_tablenormaluser'),
(39, 'Can delete table normal user', 10, 'delete_tablenormaluser'),
(40, 'Can view table normal user', 10, 'view_tablenormaluser'),
(41, 'Can add table special user', 11, 'add_tablespecialuser'),
(42, 'Can change table special user', 11, 'change_tablespecialuser'),
(43, 'Can delete table special user', 11, 'delete_tablespecialuser'),
(44, 'Can view table special user', 11, 'view_tablespecialuser'),
(45, 'Can add table personal profile', 12, 'add_tablepersonalprofile'),
(46, 'Can change table personal profile', 12, 'change_tablepersonalprofile'),
(47, 'Can delete table personal profile', 12, 'delete_tablepersonalprofile'),
(48, 'Can view table personal profile', 12, 'view_tablepersonalprofile'),
(49, 'Can add table consult', 13, 'add_tableconsult'),
(50, 'Can change table consult', 13, 'change_tableconsult'),
(51, 'Can delete table consult', 13, 'delete_tableconsult'),
(52, 'Can view table consult', 13, 'view_tableconsult'),
(53, 'Can add table buy', 14, 'add_tablebuy'),
(54, 'Can change table buy', 14, 'change_tablebuy'),
(55, 'Can delete table buy', 14, 'delete_tablebuy'),
(56, 'Can view table buy', 14, 'view_tablebuy'),
(57, 'Can add table posts', 15, 'add_tableposts'),
(58, 'Can change table posts', 15, 'change_tableposts'),
(59, 'Can delete table posts', 15, 'delete_tableposts'),
(60, 'Can view table posts', 15, 'view_tableposts'),
(61, 'Can add table videos', 16, 'add_tablevideos'),
(62, 'Can change table videos', 16, 'change_tablevideos'),
(63, 'Can delete table videos', 16, 'delete_tablevideos'),
(64, 'Can view table videos', 16, 'view_tablevideos'),
(65, 'Can add table oxygen cylinders', 17, 'add_tableoxygencylinders'),
(66, 'Can change table oxygen cylinders', 17, 'change_tableoxygencylinders'),
(67, 'Can delete table oxygen cylinders', 17, 'delete_tableoxygencylinders'),
(68, 'Can view table oxygen cylinders', 17, 'view_tableoxygencylinders');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$260000$Z3orz6hdL12NtKLqO40awu$NvP2ZJAvaACGAIBlh3bzpSOjq2+sPJy82U0HCPAy0+Y=', '2021-09-07 02:16:53.256079', 1, 'Lamyea123', '', '', 'lamyea@gmail.com', 1, 1, '2021-09-06 21:09:03.235809');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2021-09-06 21:17:07.497564', '1', 'User id: 6', 2, '[{\"changed\": {\"fields\": [\"Cv\", \"Employed\"]}}]', 8, 1),
(2, '2021-09-07 02:18:13.598943', '1', 'User id: 6', 2, '[{\"changed\": {\"fields\": [\"Salary\"]}}]', 8, 1);

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(14, 'login', 'tablebuy'),
(13, 'login', 'tableconsult'),
(17, 'login', 'tableoxygencylinders'),
(12, 'login', 'tablepersonalprofile'),
(15, 'login', 'tableposts'),
(16, 'login', 'tablevideos'),
(6, 'sessions', 'session'),
(7, 'signup', 'tabledoctoruser'),
(8, 'signup', 'tablemanageruser'),
(10, 'signup', 'tablenormaluser'),
(11, 'signup', 'tablespecialuser'),
(9, 'signup', 'tableuser');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-09-06 19:24:44.155327'),
(2, 'auth', '0001_initial', '2021-09-06 19:24:55.375296'),
(3, 'admin', '0001_initial', '2021-09-06 19:24:58.902807'),
(4, 'admin', '0002_logentry_remove_auto_add', '2021-09-06 19:24:59.413169'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-09-06 19:25:00.234749'),
(6, 'contenttypes', '0002_remove_content_type_name', '2021-09-06 19:25:02.915660'),
(7, 'auth', '0002_alter_permission_name_max_length', '2021-09-06 19:25:06.065893'),
(8, 'auth', '0003_alter_user_email_max_length', '2021-09-06 19:25:08.432576'),
(9, 'auth', '0004_alter_user_username_opts', '2021-09-06 19:25:08.605696'),
(10, 'auth', '0005_alter_user_last_login_null', '2021-09-06 19:25:09.446297'),
(11, 'auth', '0006_require_contenttypes_0002', '2021-09-06 19:25:09.486322'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2021-09-06 19:25:09.541362'),
(13, 'auth', '0008_alter_user_username_max_length', '2021-09-06 19:25:09.875603'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2021-09-06 19:25:10.245868'),
(15, 'auth', '0010_alter_group_name_max_length', '2021-09-06 19:25:23.869543'),
(16, 'auth', '0011_update_proxy_permissions', '2021-09-06 19:25:24.562036'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2021-09-06 19:25:27.205914'),
(18, 'home', '0001_initial', '2021-09-06 19:25:29.105264'),
(19, 'home', '0002_remove_tableuser_user_id', '2021-09-06 19:25:29.953866'),
(20, 'home', '0003_tablenormaluser', '2021-09-06 19:25:48.268878'),
(21, 'home', '0004_alter_tablenormaluser_id', '2021-09-06 19:26:04.381326'),
(22, 'home', '0005_alter_tablenormaluser_id', '2021-09-06 19:26:09.900245'),
(23, 'home', '0006_auto_20210719_1235', '2021-09-06 19:26:10.880943'),
(24, 'sessions', '0001_initial', '2021-09-06 19:26:12.425041'),
(25, 'signup', '0001_initial', '2021-09-06 19:27:08.395808'),
(26, 'login', '0001_initial', '2021-09-06 19:27:28.527111');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('fsqjxp0hurmxzply91z3cukcs0pua0lg', '.eJwtjE0OQDAQhe8ya6nYWtnZIG7QTBhM0tGmZdGIu2uxe-97PxecgfyOQlBDhxIJoQASZJOAeUGzZqsmKynKdc0z1NWvj-jydrde0KSC83ZhQ9rxlHDJgiuF8rvWPW6oxqGF-wHW8ylH:1mNQlA:o4pYq8G0aL98Iv6eIv6uMtl7GyJUG_CrRAvlKnbap6I', '2021-09-21 02:22:52.849444');

-- --------------------------------------------------------

--
-- Table structure for table `login_tablebuy`
--

CREATE TABLE `login_tablebuy` (
  `id` bigint(20) NOT NULL,
  `purchase_date` datetime(6) NOT NULL,
  `quantity` int(11) NOT NULL,
  `revenue_collected` double NOT NULL,
  `cylinder_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login_tableconsult`
--

CREATE TABLE `login_tableconsult` (
  `id` bigint(20) NOT NULL,
  `prescription` varchar(200) DEFAULT NULL,
  `diet_chart` varchar(200) DEFAULT NULL,
  `consultation_done` tinyint(1) NOT NULL,
  `doctor_id` bigint(20) NOT NULL,
  `post_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login_tableoxygencylinders`
--

CREATE TABLE `login_tableoxygencylinders` (
  `id` bigint(20) NOT NULL,
  `volume` double NOT NULL,
  `price` double NOT NULL,
  `discount` double NOT NULL,
  `discount_price` double NOT NULL,
  `units_available` int(11) NOT NULL,
  `cylinder_description` varchar(100) NOT NULL,
  `cylinder_pic` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_tableoxygencylinders`
--

INSERT INTO `login_tableoxygencylinders` (`id`, `volume`, `price`, `discount`, `discount_price`, `units_available`, `cylinder_description`, `cylinder_pic`) VALUES
(2, 1000, 5000, 500, 4500, 50, 'This oxygen cylinder will approximately last for 15 days. (Note: dependent of usage)', 'a.PNG'),
(3, 3000, 1500, 200, 800, 100, 'This oxygen cylinder will approximately last for 10 days', 'b.PNG');

-- --------------------------------------------------------

--
-- Table structure for table `login_tablepersonalprofile`
--

CREATE TABLE `login_tablepersonalprofile` (
  `id` bigint(20) NOT NULL,
  `systolic_pressure` int(11) DEFAULT NULL,
  `diastolic_pressure` int(11) DEFAULT NULL,
  `blood_sugar_level` int(11) DEFAULT NULL,
  `oxygen_saturation` int(11) DEFAULT NULL,
  `date_recorded` datetime(6) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_tablepersonalprofile`
--

INSERT INTO `login_tablepersonalprofile` (`id`, `systolic_pressure`, `diastolic_pressure`, `blood_sugar_level`, `oxygen_saturation`, `date_recorded`, `user_id`) VALUES
(1, 120, 80, 5, 97, '2021-09-06 20:49:33.482864', 2),
(2, 125, 95, 6, 99, '2021-09-06 20:49:50.006298', 2),
(3, 130, 80, 7, 99, '2021-09-06 20:50:02.287492', 2),
(4, 110, 85, 7, 100, '2021-09-06 20:50:34.430237', 2);

-- --------------------------------------------------------

--
-- Table structure for table `login_tableposts`
--

CREATE TABLE `login_tableposts` (
  `id` bigint(20) NOT NULL,
  `post_date` datetime(6) NOT NULL,
  `post_description` varchar(200) NOT NULL,
  `bkash_no` int(11) NOT NULL,
  `payment_value` double NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `login_tablevideos`
--

CREATE TABLE `login_tablevideos` (
  `id` bigint(20) NOT NULL,
  `caption` varchar(50) NOT NULL,
  `post_date` datetime(6) NOT NULL,
  `description` varchar(200) NOT NULL,
  `video` varchar(100) NOT NULL,
  `doctor_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `login_tablevideos`
--

INSERT INTO `login_tablevideos` (`id`, `caption`, `post_date`, `description`, `video`, `doctor_id`, `user_id`) VALUES
(1, 'Self Quarantine', '2021-09-06 20:54:31.050202', 'This video shows you who should self quarantine and how to self quarantine properly', 'images/21/Coronavirus__Who_Should_Self-Quarantine.mp4', 1, 3),
(2, 'Home care tips for mild coronavirus symptoms', '2021-09-06 20:56:59.919838', 'What should you do if you have mild covid symptoms? This video will tell you how to take care of yourself at home for mild coronavirus symptoms.', 'images/21/Home_Care_Tips_For_Mild_COVID-19.mp4', 1, 3),
(3, 'Importance of Vitamin C for the immune system', '2021-09-06 21:04:57.124965', 'Learn how vitamin C can help you improve your immune system which further will help you to prevent Covid-19', 'images/21/Can_Vitamin_C_help_prevent_COVID-19_.mp4', 2, 4);

-- --------------------------------------------------------

--
-- Table structure for table `signup_tabledoctoruser`
--

CREATE TABLE `signup_tabledoctoruser` (
  `id` bigint(20) NOT NULL,
  `specialization` varchar(30) NOT NULL,
  `highest_medical_degree` varchar(30) NOT NULL,
  `doctor_fee` double NOT NULL,
  `revenue_collected` double NOT NULL,
  `balance` double NOT NULL,
  `doctor_user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `signup_tabledoctoruser`
--

INSERT INTO `signup_tabledoctoruser` (`id`, `specialization`, `highest_medical_degree`, `doctor_fee`, `revenue_collected`, `balance`, `doctor_user_id`) VALUES
(1, 'Medicine', 'Doctor of Medicine', 500, 0, 0, 3),
(2, 'Brain', 'phd', 400, 0, 0, 4),
(3, 'Heart', 'phd', 300, 0, 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `signup_tablemanageruser`
--

CREATE TABLE `signup_tablemanageruser` (
  `id` bigint(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `salary` double DEFAULT NULL,
  `cv` varchar(100) NOT NULL,
  `employed` tinyint(1) NOT NULL,
  `manager_user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `signup_tablemanageruser`
--

INSERT INTO `signup_tablemanageruser` (`id`, `address`, `salary`, `cv`, `employed`, `manager_user_id`) VALUES
(1, 'Mirpur', 10000, 'employee_cv/21/sample_cv_0g79xIs.pdf', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `signup_tablenormaluser`
--

CREATE TABLE `signup_tablenormaluser` (
  `id` bigint(20) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `blood_group` varchar(5) NOT NULL,
  `normal_user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `signup_tablenormaluser`
--

INSERT INTO `signup_tablenormaluser` (`id`, `occupation`, `blood_group`, `normal_user_id`) VALUES
(1, 'Student', 'A+', 1);

-- --------------------------------------------------------

--
-- Table structure for table `signup_tablespecialuser`
--

CREATE TABLE `signup_tablespecialuser` (
  `id` bigint(20) NOT NULL,
  `company` varchar(30) NOT NULL,
  `blood_group` varchar(5) NOT NULL,
  `special_user_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `signup_tablespecialuser`
--

INSERT INTO `signup_tablespecialuser` (`id`, `company`, `blood_group`, `special_user_id`) VALUES
(1, 'ABC Company', 'A+', 2);

-- --------------------------------------------------------

--
-- Table structure for table `signup_tableuser`
--

CREATE TABLE `signup_tableuser` (
  `id` bigint(20) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(300) NOT NULL,
  `user_type` varchar(10) NOT NULL,
  `profile_pic` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `signup_tableuser`
--

INSERT INTO `signup_tableuser` (`id`, `first_name`, `last_name`, `gender`, `email`, `phone`, `username`, `password`, `user_type`, `profile_pic`) VALUES
(1, 'Lamyea', 'Maha', 'female', 'lamyea@gmail.com', '01712345678', 'Lamyea', 'pbkdf2_sha256$260000$pKO6vPqCV4sNYkPjDJjUao$IGmly0uzN+xVixXtShvz1Dv+/LV2FlxlvRdrpiL1S18=', 'normal', 'Lamyea_Maha.PNG'),
(2, 'Tamanna', 'Shemme', 'female', 'shemme@gmail.com', '01712345678', 'Shemme', 'pbkdf2_sha256$260000$8FeDJJhmlibxNMj7eyoee3$l2WjALeWxb8qxuN7VNZ7POnuXRqnbBuil9sczTCQzVg=', 'special', 'Tamanna_Shemme.PNG'),
(3, 'Nur', 'Mohammad', 'male', 'nur@gmail.com', '01798765432', 'Mohammad', 'pbkdf2_sha256$260000$iYI7qivw7jJLs2uB95cEeM$M9ERy3P5ugrCoM6k7LaxzLaXtfJ0TqIf/3LFgeMjF/Q=', 'doctor', 'Nur_mohammad.PNG'),
(4, 'Alice', 'James', 'female', 'alice@gmail.com', '01987654321', 'Alice', 'pbkdf2_sha256$260000$zvrMiDK3wa0WqwKUrGTpqL$9M5V87QRf5aXurcTdv8LLUSZK2jz4DR07cnBxoxMT40=', 'doctor', 'Alice_James.PNG'),
(5, 'Rashed', 'Khan', 'male', 'rashed@gmail.com', '01712345678', 'Rashed', 'pbkdf2_sha256$260000$MHuKCNzGKdSA944CDd5Aq6$etIrgBAJRSOY7RaVxXHAc9YQbM/uBkmVxDBJG4YkeXQ=', 'doctor', 'Rashed_Mahmud.PNG'),
(6, 'Fahim', 'Khan', 'male', 'fahim@gmail.com', '01712345673', 'Fahim', 'pbkdf2_sha256$260000$rZHuD5snWlY9NLNmzk9ZKW$9hXgj6TL8Z+a0eir6r0dFp3egNo5VQ0t4lAehIwZsJE=', 'manager', 'manager_kGbMcsW.PNG');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `login_tablebuy`
--
ALTER TABLE `login_tablebuy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_tablebuy_cylinder_id_3ff89af8_fk_login_tab` (`cylinder_id`),
  ADD KEY `login_tablebuy_user_id_aa44e0c0_fk_signup_tableuser_id` (`user_id`);

--
-- Indexes for table `login_tableconsult`
--
ALTER TABLE `login_tableconsult`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_tableconsult_doctor_id_b898f032_fk_signup_ta` (`doctor_id`),
  ADD KEY `login_tableconsult_post_id_1f111995_fk_login_tableposts_id` (`post_id`),
  ADD KEY `login_tableconsult_user_id_7bca502f_fk_signup_tableuser_id` (`user_id`);

--
-- Indexes for table `login_tableoxygencylinders`
--
ALTER TABLE `login_tableoxygencylinders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_tablepersonalprofile`
--
ALTER TABLE `login_tablepersonalprofile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_tablepersonalp_user_id_f98f7ba7_fk_signup_ta` (`user_id`);

--
-- Indexes for table `login_tableposts`
--
ALTER TABLE `login_tableposts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_tableposts_user_id_26ff1aac_fk_signup_tableuser_id` (`user_id`);

--
-- Indexes for table `login_tablevideos`
--
ALTER TABLE `login_tablevideos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `login_tablevideos_doctor_id_d1461237_fk_signup_ta` (`doctor_id`),
  ADD KEY `login_tablevideos_user_id_30c8fd59_fk_signup_tableuser_id` (`user_id`);

--
-- Indexes for table `signup_tabledoctoruser`
--
ALTER TABLE `signup_tabledoctoruser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `signup_tabledoctorus_doctor_user_id_6d4a4538_fk_signup_ta` (`doctor_user_id`);

--
-- Indexes for table `signup_tablemanageruser`
--
ALTER TABLE `signup_tablemanageruser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `signup_tablemanageru_manager_user_id_32a6f805_fk_signup_ta` (`manager_user_id`);

--
-- Indexes for table `signup_tablenormaluser`
--
ALTER TABLE `signup_tablenormaluser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `signup_tablenormalus_normal_user_id_9bdda244_fk_signup_ta` (`normal_user_id`);

--
-- Indexes for table `signup_tablespecialuser`
--
ALTER TABLE `signup_tablespecialuser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `signup_tablespecialu_special_user_id_0230a1c1_fk_signup_ta` (`special_user_id`);

--
-- Indexes for table `signup_tableuser`
--
ALTER TABLE `signup_tableuser`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `login_tablebuy`
--
ALTER TABLE `login_tablebuy`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_tableconsult`
--
ALTER TABLE `login_tableconsult`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_tableoxygencylinders`
--
ALTER TABLE `login_tableoxygencylinders`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login_tablepersonalprofile`
--
ALTER TABLE `login_tablepersonalprofile`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login_tableposts`
--
ALTER TABLE `login_tableposts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login_tablevideos`
--
ALTER TABLE `login_tablevideos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `signup_tabledoctoruser`
--
ALTER TABLE `signup_tabledoctoruser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `signup_tablemanageruser`
--
ALTER TABLE `signup_tablemanageruser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `signup_tablenormaluser`
--
ALTER TABLE `signup_tablenormaluser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `signup_tablespecialuser`
--
ALTER TABLE `signup_tablespecialuser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `signup_tableuser`
--
ALTER TABLE `signup_tableuser`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- Constraints for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- Constraints for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- Constraints for table `login_tablebuy`
--
ALTER TABLE `login_tablebuy`
  ADD CONSTRAINT `login_tablebuy_cylinder_id_3ff89af8_fk_login_tab` FOREIGN KEY (`cylinder_id`) REFERENCES `login_tableoxygencylinders` (`id`),
  ADD CONSTRAINT `login_tablebuy_user_id_aa44e0c0_fk_signup_tableuser_id` FOREIGN KEY (`user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `login_tableconsult`
--
ALTER TABLE `login_tableconsult`
  ADD CONSTRAINT `login_tableconsult_doctor_id_b898f032_fk_signup_ta` FOREIGN KEY (`doctor_id`) REFERENCES `signup_tabledoctoruser` (`id`),
  ADD CONSTRAINT `login_tableconsult_post_id_1f111995_fk_login_tableposts_id` FOREIGN KEY (`post_id`) REFERENCES `login_tableposts` (`id`),
  ADD CONSTRAINT `login_tableconsult_user_id_7bca502f_fk_signup_tableuser_id` FOREIGN KEY (`user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `login_tablepersonalprofile`
--
ALTER TABLE `login_tablepersonalprofile`
  ADD CONSTRAINT `login_tablepersonalp_user_id_f98f7ba7_fk_signup_ta` FOREIGN KEY (`user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `login_tableposts`
--
ALTER TABLE `login_tableposts`
  ADD CONSTRAINT `login_tableposts_user_id_26ff1aac_fk_signup_tableuser_id` FOREIGN KEY (`user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `login_tablevideos`
--
ALTER TABLE `login_tablevideos`
  ADD CONSTRAINT `login_tablevideos_doctor_id_d1461237_fk_signup_ta` FOREIGN KEY (`doctor_id`) REFERENCES `signup_tabledoctoruser` (`id`),
  ADD CONSTRAINT `login_tablevideos_user_id_30c8fd59_fk_signup_tableuser_id` FOREIGN KEY (`user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `signup_tabledoctoruser`
--
ALTER TABLE `signup_tabledoctoruser`
  ADD CONSTRAINT `signup_tabledoctorus_doctor_user_id_6d4a4538_fk_signup_ta` FOREIGN KEY (`doctor_user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `signup_tablemanageruser`
--
ALTER TABLE `signup_tablemanageruser`
  ADD CONSTRAINT `signup_tablemanageru_manager_user_id_32a6f805_fk_signup_ta` FOREIGN KEY (`manager_user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `signup_tablenormaluser`
--
ALTER TABLE `signup_tablenormaluser`
  ADD CONSTRAINT `signup_tablenormalus_normal_user_id_9bdda244_fk_signup_ta` FOREIGN KEY (`normal_user_id`) REFERENCES `signup_tableuser` (`id`);

--
-- Constraints for table `signup_tablespecialuser`
--
ALTER TABLE `signup_tablespecialuser`
  ADD CONSTRAINT `signup_tablespecialu_special_user_id_0230a1c1_fk_signup_ta` FOREIGN KEY (`special_user_id`) REFERENCES `signup_tableuser` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
